print("¡Hola, bienvenidos al laboratorio de Python!")


entero = 10
flotante = 15.5
cadena = "Hola Mundo"

suma = entero + flotante
resta = flotante - entero
multiplicacion = entero * 2
division = flotante / 2

nombre = input("¿Cuál es tu nombre? ")
print("Hola, " + nombre + "! Bienvenido al laboratorio.")
